# TechCorp SOC App - Configuration Fixes

## Date: October 30, 2025

This document describes the corrections made to align the Splunk app configuration files with the **TechCorp_SME_Architecture.md** specification.

---

## Summary of Changes

### 1. DNS Logs (techcorp_dns sourcetype)

#### Network Zone Classification - CORRECTED

**❌ Before (Too Generic):**
```
EVAL-network_zone = case(
    match(client_ip, "^192\.168\.10\."), "HQ-Corporate", 
    match(client_ip, "^192\.168\.20\."), "HQ-Servers", 
    match(client_ip, "^192\.168\.30\."), "HQ-Engineering", 
    match(client_ip, "^10\.1\."), "Factory1",              # Too broad
    match(client_ip, "^10\.2\."), "Factory2",              # Too broad
    true(), "External"
)
```

**✅ After (Specific Network Segments):**
```
EVAL-network_zone = case(
    match(client_ip, "^172\.16\.100\."), "HQ-DMZ",
    match(client_ip, "^192\.168\.10\."), "HQ-IT",
    match(client_ip, "^192\.168\.20\."), "HQ-Servers",
    match(client_ip, "^192\.168\.30\."), "HQ-Engineering",
    match(client_ip, "^192\.168\.99\."), "HQ-Management",
    match(client_ip, "^10\.1\.10\."), "Factory1-Production-IT",
    match(client_ip, "^10\.1\.20\."), "Factory1-SCADA",
    match(client_ip, "^10\.1\.30\."), "Factory1-PLC",
    match(client_ip, "^10\.1\.40\."), "Factory1-HMI",
    match(client_ip, "^10\.1\.50\."), "Factory1-Safety",
    match(client_ip, "^10\.2\.10\."), "Factory2-Production-IT",
    match(client_ip, "^10\.2\.30\."), "Factory2-PLC",
    match(client_ip, "^10\.2\.40\."), "Factory2-HMI",
    true(), "External"
)
```

**Impact:**
- ✅ Analysts can now identify SCADA vs PLC vs HMI traffic
- ✅ Safety system traffic (10.1.50.0/24) is properly classified
- ✅ Production IT vs OT networks clearly distinguished
- ✅ DMZ and Management networks now visible

---

### 2. Fortinet Firewall Logs (techcorp_fortinet sourcetype)

#### Hostname Pattern - FIXED

**❌ Before (Wrong Pattern):**
```
EVAL-site = case(
    match(hostname, "FG-HQ"), "Headquarters",      # Wrong prefix
    match(hostname, "FG-F1"), "Factory1",          # Wrong prefix
    match(hostname, "FG-F2"), "Factory2",          # Wrong prefix
    true(), "unknown"
)
```

**✅ After (Correct Pattern):**
```
EVAL-site = case(
    match(hostname, "FW-HQ"), "Headquarters",
    match(hostname, "FW-F1"), "Factory1",
    match(hostname, "FW-F2"), "Factory2",
    true(), "unknown"
)
```

**Reason:** According to architecture, firewalls are named:
- `FW-HQ-TCORP` (not FG-HQ)
- `FW-F1-TCORP` (not FG-F1)
- `FW-F2-TCORP` (not FG-F2)

#### Network Zone Classification - ENHANCED

**❌ Before (Too Generic):**
```
EVAL-network_zone_src = case(
    match(src_ip, "^192\.168\."), "Internal",      # Too broad
    match(src_ip, "^10\."), "Internal",            # Too broad
    match(src_ip, "^172\.16\."), "Internal",       # Too broad
    true(), "External"
)
```

**✅ After (Specific OT Networks):**
```
EVAL-network_zone_src = case(
    match(src_ip, "^172\.16\.100\."), "HQ-DMZ",
    match(src_ip, "^192\.168\.10\."), "HQ-IT",
    match(src_ip, "^192\.168\.20\."), "HQ-Servers",
    match(src_ip, "^192\.168\.30\."), "HQ-Engineering",
    match(src_ip, "^192\.168\.99\."), "HQ-Management",
    match(src_ip, "^10\.1\.10\."), "Factory1-Production-IT",
    match(src_ip, "^10\.1\.20\."), "Factory1-SCADA",
    match(src_ip, "^10\.1\.30\."), "Factory1-PLC",
    match(src_ip, "^10\.1\.40\."), "Factory1-HMI",
    match(src_ip, "^10\.1\.50\."), "Factory1-Safety",
    match(src_ip, "^10\.2\.10\."), "Factory2-Production-IT",
    match(src_ip, "^10\.2\.30\."), "Factory2-PLC",
    match(src_ip, "^10\.2\.40\."), "Factory2-HMI",
    true(), "External"
)
# Same for network_zone_dst
```

**Impact:**
- ✅ IT/OT boundary crossings clearly visible
- ✅ SCADA→PLC traffic properly identified
- ✅ Safety system access monitored
- ✅ Cross-factory traffic patterns detectable

---

### 3. Cisco ASA Firewall Logs (techcorp_cisco_asa sourcetype)

#### Network Zone Classification - ENHANCED

**❌ Before (Interface Only):**
```
EVAL-network_zone_src = case(
    match(src_interface, "inside"), "Internal",
    match(src_interface, "outside"), "External",
    match(src_interface, "dmz"), "DMZ",
    true(), "Unknown"
)
```

**✅ After (Interface + IP-Based):**
```
EVAL-network_zone_src = case(
    match(src_interface, "inside") AND match(src_ip, "^172\.16\.100\."), "HQ-DMZ",
    match(src_interface, "inside") AND match(src_ip, "^192\.168\.10\."), "HQ-IT",
    match(src_interface, "inside") AND match(src_ip, "^192\.168\.20\."), "HQ-Servers",
    match(src_interface, "inside") AND match(src_ip, "^192\.168\.30\."), "HQ-Engineering",
    match(src_interface, "inside"), "Internal",
    match(src_interface, "outside"), "External",
    match(src_interface, "dmz"), "DMZ",
    true(), "Unknown"
)
```

**Impact:**
- ✅ HQ firewall traffic classified by department
- ✅ IT vs Servers vs Engineering traffic distinguished
- ✅ Better incident investigation for HQ systems

---

### 4. Apache Web Server Logs (techcorp_apache sourcetype)

#### Network Zone Classification - CORRECTED

**❌ Before:**
```
EVAL-network_zone = case(
    match(client_ip, "^192\.168\.10\."), "HQ-Corporate",
    match(client_ip, "^192\.168\.20\."), "HQ-Servers",
    match(client_ip, "^192\.168\.30\."), "HQ-Engineering",
    match(client_ip, "^10\.1\."), "Factory1",
    match(client_ip, "^10\.2\."), "Factory2",
    true(), "External"
)
```

**✅ After:**
```
EVAL-network_zone = case(
    match(client_ip, "^172\.16\.100\."), "HQ-DMZ",
    match(client_ip, "^192\.168\.10\."), "HQ-IT",
    match(client_ip, "^192\.168\.20\."), "HQ-Servers",
    match(client_ip, "^192\.168\.30\."), "HQ-Engineering",
    match(client_ip, "^192\.168\.99\."), "HQ-Management",
    match(client_ip, "^10\.1\.10\."), "Factory1-Production-IT",
    match(client_ip, "^10\.1\.20\."), "Factory1-SCADA",
    match(client_ip, "^10\.1\.30\."), "Factory1-PLC",
    match(client_ip, "^10\.1\.40\."), "Factory1-HMI",
    match(client_ip, "^10\.1\.50\."), "Factory1-Safety",
    match(client_ip, "^10\.2\.10\."), "Factory2-Production-IT",
    match(client_ip, "^10\.2\.30\."), "Factory2-PLC",
    match(client_ip, "^10\.2\.40\."), "Factory2-HMI",
    true(), "External"
)
```

**Impact:**
- ✅ Detect web access from OT networks (unusual)
- ✅ Identify SCADA/HMI web portal access attempts
- ✅ Monitor factory production systems web activity

---

### 5. Windows Event Logs (techcorp_winevt_xml sourcetype)

#### Computer Zone Classification - EXPANDED

**❌ Before (Limited System Types):**
```
EVAL-computer_zone = case(
    match(Computer, "(?i)^DC-"), "Domain Controller",
    match(Computer, "(?i)^WEB-"), "Web Server",
    match(Computer, "(?i)^DB-"), "Database Server",
    match(Computer, "(?i)^FILE-"), "File Server",
    match(Computer, "(?i)^WS-"), "Workstation",
    true(), "Unknown"
)
```

**✅ After (Manufacturing-Specific Systems):**
```
EVAL-computer_zone = case(
    match(Computer, "(?i)^DC-"), "Domain Controller",
    match(Computer, "(?i)^DC\d"), "Domain Controller",
    match(Computer, "(?i)^FS-"), "File Server",
    match(Computer, "(?i)^FS\d"), "File Server",
    match(Computer, "(?i)^WEB-"), "Web Server",
    match(Computer, "(?i)^WEB\d"), "Web Server",
    match(Computer, "(?i)^MAIL-"), "Mail Server",
    match(Computer, "(?i)^MAIL\d"), "Mail Server",
    match(Computer, "(?i)^ERP-"), "ERP Server",
    match(Computer, "(?i)^ERP\d"), "ERP Server",
    match(Computer, "(?i)^CAD-"), "Engineering Server",
    match(Computer, "(?i)^CAD\d"), "Engineering Server",
    match(Computer, "(?i)^SCADA"), "SCADA Server",         # NEW
    match(Computer, "(?i)^HIST"), "Historian Server",      # NEW
    match(Computer, "(?i)^HMI"), "HMI Workstation",        # NEW
    match(Computer, "(?i)^WS-"), "Workstation",
    match(Computer, "(?i)-TCORP$"), "TechCorp System",
    true(), "Unknown"
)
```

#### Site Location - NEW FIELD

**✅ Added:**
```
EVAL-site_location = case(
    match(Computer, "(?i)HQ"), "Copenhagen-HQ",
    match(Computer, "(?i)F1"), "Aarhus-Factory1",
    match(Computer, "(?i)F2"), "Odense-Factory2",
    true(), "Unknown"
)
```

**Impact:**
- ✅ SCADA, Historian, and HMI systems now properly classified
- ✅ Can detect unusual authentication to OT systems
- ✅ Site location helps multi-site incident tracking
- ✅ Matches actual TechCorp naming conventions:
  - `SCADA01-F1` → SCADA Server at Factory 1
  - `HMI01-F1` → HMI Workstation at Factory 1
  - `DC01-TCORP` → Domain Controller at HQ

---

### 6. Saved Searches - CORRECTED

#### DNS C2 Communication Detection

**❌ Before (Lookup-dependent):**
```
search = sourcetype=techcorp_dns client_ip="192.168.30.25" 
| lookup threat_domains_lookup domain as query_domain 
| where threat_level="High" OR threat_level="Critical"
```

**✅ After (Direct Detection):**
```
search = sourcetype=techcorp_dns client_ip="192.168.30.25" 
query_domain IN ("malware-c2.example.org", "phishing-techcorp.net", 
                 "industrial-backdoor.biz", "tcorp-data-exfil.tk") 
| table _time, client_ip, query_domain, network_zone 
| sort -_time
```

**Impact:**
- ✅ Works without external lookup files
- ✅ Matches training scenario domains
- ✅ Displays network_zone for context

---

## Network Segments Reference (from Architecture)

### Corporate HQ (Copenhagen):
- **172.16.100.0/24** - DMZ (Public-facing services)
- **192.168.10.0/24** - IT LAN (Admin & office workstations)
- **192.168.20.0/24** - Server VLAN (Corporate servers)
- **192.168.30.0/24** - Engineering (CAD/Engineering workstations)
- **192.168.99.0/24** - Management (Network equipment)

### Factory 1 (Aarhus):
- **10.1.10.0/24** - Production IT (Manufacturing IT systems)
- **10.1.20.0/24** - SCADA Network (Supervisory control)
- **10.1.30.0/24** - PLC Network (Programmable Logic Controllers)
- **10.1.40.0/24** - HMI Network (Human Machine Interfaces)
- **10.1.50.0/24** - Safety Systems (Emergency shutdown)

### Factory 2 (Odense):
- **10.2.10.0/24** - Production IT (Manufacturing IT systems)
- **10.2.30.0/24** - PLC Network (Packaging & quality control)
- **10.2.40.0/24** - HMI Network (Operator interfaces)

---

## Key Systems Reference

### Corporate HQ:
- **DC01-TCORP** (192.168.20.10) - Domain Controller
- **FS01-TCORP** (192.168.20.15) - File Server
- **WEB01-TCORP** (172.16.100.10) - Web Server
- **MAIL01-TCORP** (172.16.100.20) - Mail Server
- **ERP01-TCORP** (192.168.20.25) - ERP Database
- **CAD01-TCORP** (192.168.30.10) - Engineering Server
- **FW-HQ-TCORP** (172.16.100.1) - Cisco ASA Firewall

### Factory 1 (Aarhus):
- **SCADA01-F1** (10.1.20.10) - SCADA Server
- **HIST01-F1** (10.1.20.15) - Historian Database
- **HMI01-F1** (10.1.40.20) - HMI Station 1
- **HMI02-F1** (10.1.40.21) - HMI Station 2
- **PLC-LINE1** (10.1.30.50) - Production Line PLC
- **FW-F1-TCORP** (10.1.10.1) - Fortinet Firewall

### Factory 2 (Odense):
- **HMI01-F2** (10.2.40.20) - HMI Station
- **PLC-QC2** (10.2.30.60) - Quality Control PLC
- **PLC-PACK2** (10.2.30.65) - Packaging Line PLC
- **FW-F2-TCORP** (10.2.10.1) - Fortinet Firewall

---

## Benefits of These Corrections

### For SOC Analysts:
1. **Precise Network Visibility**: Can distinguish between IT, OT, and safety networks
2. **IT/OT Boundary Detection**: Immediately see cross-boundary traffic
3. **Manufacturing Context**: Understand which factory and system type
4. **Incident Investigation**: Quickly identify critical systems (SCADA, HMI, Safety)

### For Training Scenarios:
1. **Realistic Patterns**: Matches actual industrial network segmentation
2. **Attack Detection**: Lateral movement IT→OT clearly visible
3. **Priority Assessment**: Safety systems flagged immediately
4. **Multi-Site Correlation**: Track incidents across Copenhagen, Aarhus, Odense

### For Compliance:
1. **Network Segmentation**: Proves IT/OT separation
2. **Access Control**: Monitor who accesses critical OT systems
3. **Audit Trail**: Site and system type clearly documented
4. **Safety Systems**: Special handling for 10.1.50.0/24

---

## Testing Recommendations

1. **Test Network Zone Classification:**
   ```spl
   index=dns sourcetype=techcorp_dns 
   | stats count by network_zone 
   | sort -count
   ```
   Should show all 13 network zones

2. **Test Firewall Site Detection:**
   ```spl
   index=firewall (sourcetype=techcorp_cisco_asa OR sourcetype=techcorp_fortinet) 
   | stats count by site 
   ```
   Should show: Headquarters, Factory1, Factory2

3. **Test Windows Computer Classification:**
   ```spl
   index=windows sourcetype=techcorp_winevt_xml 
   | stats count by computer_zone, site_location
   ```
   Should show SCADA, HMI, Historian types with correct sites

4. **Test OT Network Traffic:**
   ```spl
   index=firewall sourcetype=techcorp_fortinet network_zone_src="Factory1-SCADA" 
   | stats count by network_zone_dst
   ```
   Should show SCADA→PLC, SCADA→HMI traffic

---

## Files Modified

- ✅ **props.conf** - All sourcetype definitions updated
- ✅ **savedsearches.conf** - DNS C2 detection corrected
- ⚠️ **transforms.conf** - No changes needed (already correct)

---

**Verification Status:** ✅ All configurations now align with TechCorp_SME_Architecture.md  
**Date Verified:** October 30, 2025  
**Ready for Training:** Yes
